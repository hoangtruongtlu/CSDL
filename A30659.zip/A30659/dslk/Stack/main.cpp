#include <iostream>
using namespace std;
#include "stack.h"
int main()
{
	Stack<int> s;
	s.Push(1);
	s.Push(3);
	s.Push(5);
	s.Push(7);
	cout<<s.Pop()<<endl;
	return 0;
}