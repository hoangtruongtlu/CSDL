#include <iostream>
using namespace std;
#include "queue.h"
int main()
{
	Queue<int> s;
	s.EnQueue(1);
	s.EnQueue(3);
	s.EnQueue(5);
	s.EnQueue(7);
	cout<<s.DeQueue()<<endl;
	return 0;
}