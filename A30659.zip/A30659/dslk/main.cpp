#include <iostream>
using namespace std;
#include "list.h"
#include "date.h"
#include "stack.h"
#include "queue.h"
int main()
{

	return 0;
}